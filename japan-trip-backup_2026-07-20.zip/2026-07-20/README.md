# Japan Trip — full data backup · 2026-07-20 (app v2 b8)

## What's here
- itinerary_full.json — all 18 planned days, 191 stops (29 alternatives) extracted from the live app: id, time, name+Japanese, category, address, details, map link, per-day hotel. This is the machine-readable master of the itinerary.
- board_and_reference.json — booking board (9 items), 4 static confirmed tickets, 26 phrasebook entries, allergy cards.
- firestore_state.json — the live shared sync state (checkmarks, went/saved moves, custom events) at snapshot time.
- index_v2_b8.html — the complete app as deployed (itinerary HTML included = human-readable master).
- csv/ — the 18 source day CSVs + hotels + MyMaps imports.
- PROJECT_INSTRUCTIONS.md, osaka-planning-draft.md — planning state.

## What is NOT here (by nature)
- File attachments (ticket PDFs/images) live in IndexedDB on each phone — not reachable from outside. An in-app export button is the fix if wanted.
- GitHub repo itself is a live copy of the app (HananGershon/japan-trip).

## Restore paths
- App: re-upload index_v2_b8.html as index.html to the repo.
- Shared state: write the values from firestore_state.json back into localStorage keys (v2_state, jt_done, jt_book, jt_cbk) on one device — sync spreads them.
- Itinerary content: itinerary_full.json + csv/ are enough to rebuild the day sections from scratch.

## ⚠️ Noted at snapshot time
jt_cbk (custom events) was EMPTY in Firestore, though 4 events existed earlier today. If those were not deleted intentionally during b7/b8 testing, recover them by re-adding via the + sheet.
