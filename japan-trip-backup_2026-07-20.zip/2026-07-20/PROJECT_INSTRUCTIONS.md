# Japan Trip 2026 — Project Instructions & Context

Trip dates: Sept 6 – Oct 12, 2026 (37 days). Travelers: Hanan + wife Pola (ages 39/48).

## ⚡ CURRENT STATUS SNAPSHOT (as of July 19, 2026, end of day — read this first)

**Planning:** Days 1–18 (Sept 7–24, Tokyo→Alps→Kyoto→Uji) fully planned in CSVs. NOT planned: Osaka Sept 24–30 (incl. USJ tickets question), Hakone Sept 30–Oct 2, Tokyo 2 Oct 2–12. Next planning step = Osaka.

**The app:** live at https://hanangershon.github.io/japan-trip/ (GitHub Pages, repo HananGershon/japan-trip), installed on Hanan's phone BOTH as PWA and as Android APK (WebView shell that loads the live URL — content/design updates flow via GitHub commit, NO reinstall). Features: bottom nav (Trip/Days/Map/Browse/More), booking board + confirmed tickets with FILE ATTACHMENTS (IndexedDB) + custom bookings modal, collapsible day groups, per-day route map with numbered ordered pins, live weather, checkboxes (visited), Phrasebook with native Android Japanese TTS, Allergies tab (Hanan: peach/nectarine/penicillin; Pola: kiwi — header just says アレルギー), English-only UI.
- **Design source of truth = the current index.html in app-deploy/ (Hanan's own redesign via Claude Design + my fixes). build_app.py is STALE for design — patch content into index.html directly, don't regenerate.**
- **July 20, 2026: Hanan applied a NEW cream/washi design directly on GitHub** (warm cream palette `#fbf5e7`, ink-brown text, terracotta `#b95f55` + gold `#b78b45` accents, rounder corners, soft day-enter animation) and the local app-deploy/index.html was re-synced from his upload. The file ends with a file-picker enhancement IIFE that wires inputs to the global `window.saveFile` — this version WORKS (unlike the old broken enhancement script); don't strip it.
- **July 20, 2026 (later): CSS CONSOLIDATED to ONE design layer** per Hanan's design prompt. The 4 accumulated `<style>` blocks (base + `#calm-refinement` + `#file-picker-fix` + `#actual-japanese-calm-redesign`, layered by different AIs) were property-level-merged into a single `<style id="design-washi">` block with washi values as final. Zero JS/markup changes (all 3 script blocks verified byte-identical; 373 onclick + 213 onchange handlers intact). Deliberate refinements: `--mut` #82776b→#6e6557 (contrast), `.wx` weather pill blue→sage/teal, `.file-status`→var(--mut). Version stamp format (per Hanan, July 20): **`vN · bK · DD.MM HH:MM`** in the header h1 — vN = major version (v1 = current app, v2 = new shell), bK = build number, **incremented on EVERY patch** so Hanan can tell if the installed version is the latest. Current: index.html = v2 · b8 (20.07 20:43); b5-b7 backups in `_trash/`, v1 at `_trash/index_v1_b1_2026-07-20.html`. b8 (Hanan's field feedback): ＋ sheet step 2 gained Remove (undo just-created event) + Edit (back to prefilled form; nwAddSave updates in place via `nwAddForm.dataset.edit` instead of duplicating); nwAddOpen now also clears the time field and the edit flag. Old 4-layer file: `_trash/index_washi-4layers_2026-07-20.html`; pre-washi: `_trash/index_pre-washi_2026-07-19.html`. **Rule: edit design ONLY inside `#design-washi`; never append new style patch layers.** NOT yet uploaded to GitHub as of this note — pending Hanan's preview + manual upload.
- Sandbox note: bash/VM writes to pre-existing files in the mounted folder are denied (create/mv allowed, overwrite/delete not) — to replace a file, `mv` the old one aside (e.g. into `_trash/`) and `cp` the new one in; host-side Edit/Write tools also work.
- **Repo READ access works from the sandbox via web fetch** (github.com repo pages + raw.githubusercontent.com) — use it to check what's live/committed. Raw fetches truncate at ~68KB (index.html is ~330KB), so full-file sync still requires Hanan to upload the file to the chat/folder. Git push and the GitHub connector remain unavailable in Cowork (his "GitHub Integration" connector only serves Chat/Projects/Claude Code) — uploads to GitHub stay MANUAL by Hanan.
- Android project v2 (japan-trip-android-project-v2.zip) adds onShowFileChooser — required for Attach file; system picker includes Google Drive natively. Hanan rebuilt + installed.
- Uploads to GitHub are MANUAL by Hanan (drag index.html → commit). GitHub connector attempted but NOT active in-session (check again in new sessions — if GitHub tools exist, Claude can commit directly). Google Drive connector IS connected.

**App v2 track (started July 20, 2026):** Hanan approved the "Now screen" concept (mock: `mockup-now-screen.html`). **July 20 (evening): v2 PROMOTED — per Hanan, v2 now lives directly in `app-deploy/index.html`** (v2.html retired to `_trash/v2_b4_superseded-by-index_2026-07-20.html`; b4 pre-restyle backup at `_trash/index_v2_b4_2026-07-20.html`). ⚠️ As of b5, the LIVE GitHub index.html was still the OLD July 19 build (stamp "v19.07.2026 19:14", no v2, no washi consolidation) — Hanan still needs to upload the new index.html. v2 = the original app (all script blocks byte-identical since v1) + additive `#v2-components` style block + `#v2-now` script.
- **DONE (July 20):** Now screen built at runtime from existing day sections (no data duplication) — time-aware current stop, 見せる Show fullscreen JP card, Plan B alternatives, Up next, Later today, Earlier-today shelf with ✓Went/→Today/📅Later (passed stops NEVER auto-marked visited); 3-tab nav (Now/Triphub/More) via wrapped show(); SIM bar (day picker shows dates, auto-hidden during real trip dates); add-event FAB + centered sheet (name/date/time/details + attach file) writing to existing jt_cbk + saveFile/IndexedDB, custom events merged+sorted into the Now timeline with `added` tag and 🎫 Files chip; open-bookings banner reading #home .todo checkboxes; evening mode = tomorrow preview + hotel-change warning; kicker shows date not day-number. All v2 user state via `V2Store` (localStorage 'v2_state') — single store, sync-engine-ready.
- **DONE (July 20, b2-b4):** Trip hub implemented (mock: `mockup-trip-screen.html`, approved incl. SVG stroke icons — NO emojis, Hanan: "emojis look early-2000s") — compact countdown, 6 leg rows (day colors, planned/unplanned), Still-to-book synced two-way with #home board (urgency chips: red NOW/≤14d, gold ≤45d), Confirmed & tickets rows with live IndexedDB file-count badges + ✕ delete for custom (cb*) tickets via delBooking, Tools row (Hotels/Map/Browse). ＋ button moved INTO the nav bar (was overlapping content); SIM bar collapsible via ⏱; bookings banner → triphub; More-screen emojis → SVGs. Old #home has no nav entry anymore but stays in DOM as the data source for board/tickets — do NOT delete it without migrating that data.
- **DONE (July 20, b5):** legacy screens restyled to the v2 calm language (CSS inside `#design-washi` + 2 tiny markup swaps; zero JS changes, scripts verified byte-identical, 397 onclick/219 onchange intact): Days & More screens now open with a `nw-kicker` label (was big h2); day-page header flipped to the v2 kicker pattern — date/day-number is now a small uppercase kicker in the day color, area names are the title, underline bar removed; dashed row separators → solid hairline (`var(--line)`) in days list; day dots circle → 10px rounded square (matches `.hb-dot`); Today button gradient → flat #b5685e per `.nw-go`. Allergy screen checked: per-person tabs (Hanan/Pola), JP cards + TTS, SVG icons — already conforms, no change needed.
- **DONE (July 20, b6-b7 — SYNC LIVE + add-event rework):** b6 uploaded by Hanan, sync between devices CONFIRMED WORKING (he tested). b7 (mock `mockup-add-event-b7.html`, approved): ＋ sheet got a "This is a booking — show under Confirmed & tickets" checkbox → jt_cbk entries carry `hub:1|0` (missing field = legacy = 1, so his 4 pre-b7 events stay in the hub); renderCustom skips hub===0 (original indexes preserved — delBooking(i)/cb-ids unchanged); Later-today rows of custom events got an ✕ (calls nwDelTkt) so deletion isn't hub-only; window.saveFile wrapped in #v2-now — attaching a file to a hub:0 event auto-promotes it to the hub. Known pre-existing v1 bug (NOT b7's): delBooking splices jt_cbk so later cb-indexes shift while IndexedDB files stay keyed to old cbN — file-attachment mismatch possible after deleting a middle event; fix when stripping old home.
- **v2 TODO:** Hanan to upload b7; eventually strip old home UI (after migrating its board/tickets data — #home is still the data source for triphub; fix cb-index/files bug then too).
- **DONE (July 20, b6): two-device sync built** — new `#v2-sync` script (appended before `</body>`; b5 content otherwise byte-identical). Firebase project: **japan-trip-7880e** (Hanan's Google account, Spark free tier, Firestore Standard, asia-northeast1). Design: syncs 4 localStorage keys (`v2_state`, `jt_done`, `jt_book`, `jt_cbk`) to ONE Firestore doc `trips/hanan-pola-japan-2026-x7k2qv9m3f8zp1cw`, per-key last-write-wins ({v,t,dev}), real-time onSnapshot, offline via persistentLocalCache, localStorage.setItem hooked (installed once, catches app writes; `jt_book` recomputed from DOM on write because the board handler holds a stale closure map). NOT synced: `jt_day` (per-device screen), SIM state, IndexedDB file attachments (blobs stay per-device; only ticket metadata via jt_cbk syncs). App remains fully functional if Firebase fails/offline. Firebase config is public in the repo (fine — API key isn't a secret); protection = unguessable trip ID in rules. **⚠️ Firestore was created in TEST MODE which EXPIRES ~Aug 19, 2026 (mid-prep, before trip!) — Hanan MUST paste the scoped rules (given in chat July 20) before then; added to action items.** Testing: needs two DIFFERENT browsers (two tabs share localStorage → meaningless).
- **NOTE:** Hanan's Claude license may lapse within days (his words, July 20) — prioritize shippable increments and keep this file current at every step.

**Immediately pending:** (1) Hanan has a DESIGN PROMPT he wants implemented on the current index.html — waiting for him to paste it. (2) Action items list below (kawadoko booking still urgent). (3) Then Osaka planning ("the BE part" as Hanan calls the remaining trip planning).

Read this file at the start of every session in this project before doing anything else. It replaces having to re-explain context in chat.

## Trip structure (hotels, in order)

| Dates | Hotel | Area |
|---|---|---|
| Sept 6-10 | Section L Hamamatsucho | Tokyo - Hamamatsucho |
| Sept 10-13 | Mi-Hotel Kitashinjuku | Tokyo - Kita-Shinjuku |
| Sept 13-14 | Kisoji no Yado Iwaya | Kiso-Fukushima |
| Sept 14-17 | Ascend Collection Hotel Takayama | Takayama area |
| Sept 17-18 | Hotel Keihan Nagoya | Nagoya |
| Sept 18-24 | KABIN Taka | Kyoto |
| Sept 24-30 | Ruka Hotel Tennoji | Osaka - Tennoji |
| Sept 30-Oct 2 | Sengokuhara Shinanoki Ichinoyu | Hakone / Sengokuhara |
| Oct 2-6 | KAIKA Tokyo by THE SHARE HOTELS | Tokyo |
| Oct 6-12 | Hotel DIAMOND | Tokyo - Shibuya, Dogenzaka (final confirmed hotel) |

Day-trips folded into the Tokyo stretch: Kamakura (day trip), plus a Kiso Valley/Takayama car-rental leg (see below).

## Rental car — CONFIRMED booking

Reservation #99997888300, SUV1 class, total 79,898 JPY.
- Pickup: Sept 13, 2026, 14:00 — Nakatsugawa Station Shop, 2-3-5 Ota-machi, Nakatsugawa-shi, Gifu 508-0033, tel 0573-62-0130
- Return: Sept 17, 2026, 19:00 — Nagoya Nishiki Shop, 460-0003 Nagoya-shi, Naka-ku, Nishiki 2-5-34
- Toyota Rent a Car's site/simulator does not accept URL parameters or pre-filled links — store search and booking must be done interactively (search by store name) or by phone. Don't guess URLs for this system.

## Traveler profile — who Hanan and his wife are

Read this before making judgment calls on what to recommend, not just how to source it.

- Consistently prefer authentic, real quality over trend/gimmick/spectacle — in food (rejected Taiwan castella, standalone tebasaki-as-a-meal), in sights (leaned toward Inuyama's genuine original castle over Nagoya's reconstructed/currently-closed one, favored the Magome-Tsumago hike, Shirakawa-go, Kamikochi over packaged tourist stops).
- **Serious coffee people** — appreciate specialty/third-wave coffee culture specifically, not just "a coffee." Treat the cross-city coffee list in `additional-sources-and-notes.md` as high-value.
- **Serious cocktail bar enthusiasts, and knowledgeable about it** — this is an important, recurring evening activity to plan for in big cities (Tokyo, Kyoto, Osaka), not just an occasional nice-to-have. They specifically want bars with genuinely skilled, knowledgeable bartenders — real craft — and explicitly want to avoid tourist-gimmick bars with inflated prices. Source these with the same rigor as restaurants (Tabelog/Google Maps ratings, no TripAdvisor, avoid anything that reads as a tourist-trap). Existing leads: SG Club, Bar Ishinohana, The Bellwood (all Shibuya, researched for the Oct 6-12 stay).
- Despite the above, day-to-day evenings during busy sightseeing stretches still default to light/casual/no-reservation — cocktail bars are the intentional exception to seek out periodically in big cities, not a replacement for that default every night.
- **ALLERGIES (critical for food planning):** Hanan — peach (桃), nectarine (ネクタリン), penicillin (ペニシリン, medication). Wife Paula — kiwi (キウイ). CHECK every dessert/parfait/fruit-sandwich recommendation against these (Japan loves seasonal peach desserts in Sept and kiwi in fruit parfaits — e.g. flag fruit contents at places like Nakamura Tokichi parfaits, HIIRAGI kakigori, OUCA seasonal flavors). Allergy tab exists in the app (Japanese script + TTS, per-person sub-tabs).
- **Strongly averse to smoking — indoor-smoking venues are a hard NO** (per Hanan, July 2026). Always check Tabelog's smoking field before recommending any bar/restaurant; many classic Japanese counter bars permit smoking, so this filter matters especially for cocktail bars.
- Cost-conscious in a practical, not restrictive, way — skipped the JR Pass after doing the math on it not being worth it in 2026, but not opposed to spending on genuinely good food/drink/experiences.

## Presentation rules (per Hanan, July 2026 — ALWAYS follow in chat)

- **Action items / task lists: always present as a list, one item per line.** Never bury them in prose. Keep a running action-items list and proactively remind Hanan of it.
- **Itineraries/routes in chat: one stop per line** — never comma-joined in a single paragraph. Clear names.

## Standing sourcing & formatting rules

- Ratings/reviews: Tabelog or Google Maps ONLY (3.5+ / hundreds of reviews preferred where possible).
- **TripAdvisor is banned outright — do not search it, cite it, or let it appear in results (use blocked_domains on searches).**
- Social/blog/YouTube sourcing: only Japanese locals or verified long-term (years-long) foreign residents. Reject short-term travel influencers (confirmed failures: itsgracechin, mr.tokyo.adventures — bios show only months in Japan). Time Out Tokyo: approved as a discovery source (per Hanan, July 2026) — can be used to find interesting leads, but every pick taken from it must then be verified against other sources (Tabelog/Google Maps ratings etc.) before being treated as a legitimate recommendation. Never sole source.
- Approved long-term-resident source: **Sunny in Japan** (YouTube/Instagram @itssunnyinjapan) — Kyoto/Osaka-based, use for those cities and surrounding day trips.
- Personal source: a KMZ map from "Gal" (ptitim.com), a Hebrew-language food blogger — already cross-referenced into Tokyo-area days (Sept 7-11). 736 placemarks extracted; use for any remaining Tokyo-area gaps.
- Avoid trend/gimmick food (e.g. Taiwan castella) unless genuinely high quality — prefer established, real specialties over viral food.
- Any street mentioned needs real start/end cross-streets or landmarks.
- Big-city evenings default to "light, casual, no reservation" unless something is genuinely standout-specific.
- Japanese script names required alongside every venue (used for direct Google Maps search).
- Public transit only, except the Sept 13-17 Kiso Valley/Takayama/Nagoya car leg (explicitly authorized).
- Before citing anything, verify by actually reading the fetched page content — don't guess URLs or present unverified info as fact, especially for booking-critical logistics (car rental, train reservations).

## File naming convention

`Japan Day N - D.9.csv` where Day N corresponds to Sept (6+N) — e.g. Day 1 = Sept 7, Day 7 = Sept 13, Day 12 = Sept 18. CSV columns: `Time,Name,Address` (some early files also have a `Description` column).

There's also a comprehensive HTML file (`Japan Itinerary Sept 7-17.html` — renamed July 2026, it covers Sept 7-17 despite the old 13-17 name) with fuller notes/attributions/alternatives that don't fit in the lean CSVs — kept in sync with the CSVs for that date range. The old `Tokyo_Itinerary_Preview.html` (Sept 7-8 draft) was retired July 2026: its unique valid items (Tokyo Station Marunouchi facade, two snack notes) were merged into the comprehensive HTML; its Seaside Top Observatory item was dead info (closed 2021) and its Gold Bar/Roku Nana bar alts were superseded by verified alternates. File moved to `_trash/` — Hanan can empty that folder himself.

## Mobile deliverables (added July 2026)

- `Japan Trip - Mobile.html` — single-file mobile web-app (day chips, tap-to-Maps links, works offline). Generated from the Day CSVs by `build_mobile_app.py` — **rerun `python3 build_mobile_app.py` after any CSV change** to regenerate both mobile files.
- **STATUS: installed and working on Hanan's phone as a PWA (July 19, 2026)** — full install (manifest + sw.js + icon-192/512 PNGs in repo root; icons must be real PNGs, a JPEG-renamed-PNG caused Chrome to only offer "create a shortcut"). Offline works via service worker (network-first). Version stamp shows in the header (vDD.MM.YYYY HH:MM from build time) — that's how Hanan verifies he's on the latest build.
- **The app is LIVE at https://hanangershon.github.io/japan-trip/** (GitHub Pages, personal repo HananGershon/japan-trip, file `index.html`, public). **⚠️ DESIGN SOURCE-OF-TRUTH CHANGE (July 19, 2026 evening):** Hanan redesigned index.html himself (via Claude Design) and that file is now the live app — `app-deploy/index.html` is HIS version (with my fixes: removed a broken runtime "enhancement" script that killed Attach file; kept his Add-booking modal). **build_app.py is now STALE for design** — regenerating from it would clobber his design. Future itinerary/content updates must be patched INTO the current index.html directly (or his CSS ported into build_app.py first). Also: MainActivity.kt updated with WebChromeClient.onShowFileChooser (file inputs did nothing in the WebView without it — this was the root cause of Attach failing in the APK; system picker includes Google Drive natively). He must rebuild the APK once (japan-trip-android-project-v2.zip).
Update flow (OLD, pre-redesign): run `python3 build_app.py` — it outputs **`app-deploy/index.html`**. ALL five deployment files live in the **`app-deploy/`** subfolder (index.html, manifest.json, sw.js, icon-192.png, icon-512.png — per Hanan, kept together so uploading to GitHub is easy; index.html always under this exact name, no renaming). Hanan uploads it to the repo root (Upload files → commit to main); phone picks it up on refresh. Map day-filters default to ALL OFF (per Hanan) — user turns on only the day they want. Old intermediate copies (Japan Trip - App.html, index_for_github.html) retired to `_trash/`. Note: an APK build was attempted and is NOT possible from the sandbox (dl.google.com/maven.google.com blocked) — hosting replaced it. A stray copy of index.html was committed to the company repo bitbucket.org/biorce/ui-automation; Hanan lacks delete permission — he'll ask an admin to remove it.
- **App IA redesign (July 19, 2026 v17:29):** top day-chips strip REMOVED → bottom navigation bar with 5 tabs (Trip / Days / Map / Browse / More), Days screen grouped by leg with pinned Today button, More screen collects Phrasebook/Allergies/Hotels subpages (with back rows). Per Hanan: acting as PM+UX+designer; guiding references = friend's app screenshots + shiroyo.com + Wanderlog; principle = group by topic, reduce visual clutter, fewer buttons on main surfaces.
- **App feature set (as of July 19, 2026 v15:30 build):** day chips + Home ("★ Trip": countdown, legs overview, BOOKING BOARD mirroring the action-items list with deadline countdowns + done-checkboxes, confirmed-reservation tickets), Browse-by-category tab (auto-classified places, leg filter, day-link chips), Phrasebook with ja-JP speech synthesis (incl. "kin'en seki onegaishimasu" = non-smoking seat), timeline rail in day view, numbered stops + ordered route lines on map with fit-to-day camera, tonight's-hotel card, live weather pills (Open-Meteo), collapsed detail cards (title+type chip+small address; bullets on expand). UX ideas sourced from shiroyo.com and a friend's app screenshots (July 2026). IMPORTANT: the booking board in the app must be kept in sync with the ACTION ITEMS list below (edit BOOK_TODO/BOOKED in build_app.py).
- `Japan Trip - App.html` — the APP PROTOTYPE (Phase 1 of the app plan): everything the plain mobile HTML has, PLUS an integrated map tab (Leaflet loaded at runtime, 120 pins colored by day, day filter, popups with Google Maps links) and per-item checkboxes (check → strikethrough + dim, persisted in localStorage — marks visited/skipped). Generated by `build_app.py` from the day CSVs + `geocode_cache.json` (pattern→lat/lon; geocoded via Nominatim through the browser July 2026 — sandbox blocks direct geocoding APIs; new venues need a cache entry). Phase 2 UPDATE (July 19, 2026): Hanan installed Android Studio on his personal machine. Complete WebView-shell project delivered as `japan-trip-android-project.zip` (+ source in `android-project/`): loads the LIVE GitHub Pages URL (so content/design stay OTA-updatable — no reinstalls for itinerary changes), opens external links (Maps/Tabelog) in native apps, and bridges the phrasebook to native Android Japanese TTS via window.AndroidTTS (WebView lacks speechSynthesis; web say() falls back gracefully). He builds/installs it himself in Android Studio. Design still lives in the HTML/CSS (build_app.py), NOT in Android layouts — keep iterating there. The plain mobile HTML + MyMaps CSVs stay maintained as the backup plan.
- `MyMaps - <leg>.csv` files — one per trip leg (Tokyo leg 1, Kiso-Takayama-Nagoya, Hotels; more as legs get planned), each imported into its own Google My Map, pins styled by the Day column. Leg mapping lives in `LEGS` inside `build_mobile_app.py` — extend it when planning Kyoto/Osaka/Hakone/Tokyo-2.

## Day-by-day status

| Day | Date | Status |
|---|---|---|
| 1-3 | Sept 7-9 | Done — Shiba/Tsukiji/Ginza, Zojoji/Nihonbashi, teamLab/Ebisu |
| 4 | Sept 10 | Done — Shinjuku/Harajuku |
| 5 | Sept 11 | Done — Shimokitazawa/Kagurazaka |
| 6 | Sept 12 | Done — Kamakura day trip |
| 7 | Sept 13 | Done — Tokyo to Kiso Valley (car pickup 14:00) |
| 8 | Sept 14 | Done — Magome-Tsumago hike, on to Takayama |
| 9 | Sept 15 | Done — Shirakawa-go/Gokayama |
| 10 | Sept 16 | Done — Kamikochi |
| 11 | Sept 17 | Done — Takayama to Nagoya (car return 19:00) |
| 12 | Sept 18 (Fri) | Done — REWORKED AGAIN July 2026 (per Hanan: shorter Nagoya, hotel FIRST): Toyota Museum only (9:30-11:15) → Houraiken lunch 11:50 → optional 20-min Atsuta stroll → 13:45 Nozomi → hotel bag-drop 14:50 → Kintetsu to Ogura → **Nintendo Museum 16:30-20:00 (Hanan HAS tickets)** → back ~21:00 |
| 13 | Sept 19 (Sat) | Done — Higashiyama at dawn (Kiyomizu 6:00, lanes, KeFU coffee, Kodai-ji, Chion-in, Kagizen) → Ginkaku-ji + Philosopher's Path → evening Pontocho + KI NO BI House gin bar |
| 14 | Sept 20 (Sun) | Done — REVISED July 2026: **NARA DROPPED (Hanan: not interested)** → Ohara half-day instead (Bus #17 7:45, Sanzen-in ¥700, Hosen-in ¥900 matcha-with-view included) → kimono shopping (Ochikochiya + Daiyasu, both near hotel) → KYOTO STAR BAR 17:30 (charge waived before 19:00) → Tosuiro (RESERVE) |
| 15 | Sept 21 (Mon, HOLIDAY) | Done — REVISED: **Fushimi Inari moved to DAWN (6:00, per Hanan)** → JR back → **teamLab Biovortex 9:00 (Hanan HAS tickets)** → Tansu-ya (Avanti) → Higashi Honganji + Shosei-en → easy evening (holiday Monday, most bars shut) |
| 16 | Sept 22 (Tue, HOLIDAY) | Done — REVISED with Sunny's Arashiyama picks: bamboo dawn 6:45 → Tully's (her %Arabica alternative) → Tenryu-ji → eX cafe grill-dango → hidden trio Gio-ji/Adashino/Otagi → **Yoshimura soba lunch (her pick, 3.52/1010, non-smoking, holiday hrs 11-17)** → Kimono Forest → Kinkaku-ji 15:00 → Gion evening → Bar Kugel |
| 17 | Sept 23 (Wed, HOLIDAY) | Done — Kurama→Kibune hike (trail verified open) + Kifune Shrine + kawadoko river-platform lunch (season to Sept 30 — RESERVE: Hiroya/Fujiya/Beniya) → Nishiki + SOU・SOU/Chicago kimono shopping → Menya Inoichi farewell dinner |
| 18 | Sept 24 (Thu) | Done — Uji en route to Osaka (Byodo-in, tea street, Ujigami) → Ruka Hotel Tennoji ~15:30. Luggage: takkyubin from KABIN on the 23rd, or Uji lockers |
| — | — | **Kyoto strategic notes**: Sept 19-23 is SILVER WEEK 2026 (Sept 21 Respect-for-Aged + Sept 22 bridge + Sept 23 equinox — verified, nippon.com) → plan built around dawn starts + hidden picks + Uji on calm post-holiday Thursday. NO CAR for this leg (all rail; holiday roads jam). Gion: private side-alleys off Hanamikoji banned to tourists since 2024 (¥10k fines) — public streets fine. Kyoto doc finding: the docx contains NO Kibune/Kurama/Ohara content despite its filename; Kurama day planned from verified external sources. Saiho-ji moss temple ("absolute must" per doc) NOT scheduled — needs advance booking + a free half-day; ask Hanan if he wants it swapped in. Kimono/yukata verdict (Japanese sources, July 2026): for mid-Sept the "textbook" garment is a hitoe (単衣 unlined kimono), but a dark/autumn-toned yukata is fine AND September = end-of-season yukata sales (up to 75% off); best play = sale yukata + cheap secondhand hitoe. Shops chosen from Japanese-buyer sources (めいじのキモノカルネ blog etc.): Ochikochiya 彼方此方屋 (Day 14; ochicochiya.com), Daiyasu だいやす (Day 14 alt; kimono-daiyasu.com), Tansu-ya Avanti (Day 15; tansuya.jp), Chicago Kyoto + SOU・SOU (Day 17; chicago.co.jp/kyt.html, sousou.co.jp). Modoribashi 戻橋 (¥500 antique floor) noted but off-center — not scheduled. |
| — | — | **ACTION ITEMS (Hanan's list — always present one per line, keep reminding):** 1. Book kawadoko lunch Sept 23 (Hiroya/Fujiya/Beniya via kyoto.travel links) — URGENT, holiday. 2. Reserve Nozomi seats Sept 18 ~13:45 Nagoya→Kyoto. 3. Reserve Tosuiro for Sept 20 evening (tousuiro.com). 4. Book Bar Kugel Sept 22 by phone. 5. Arrange takkyubin luggage KABIN→Ruka on Sept 23. 6. DECIDE: Saiho-ji moss temple (doc: "absolute must", needs advance booking + half-day — not currently scheduled). 7. **Ghibli Museum tickets — Hanan wants to go (Tokyo)**; sales open the 10th of each month for the following month, sell out fast. 8. **Withdraw cash by Sept 8** — perfume-workshop balance is CASH ONLY. 9. Later: Universal Studios tickets for Osaka leg (per Hanan July 20: always say "Universal Studios", not "USJ"). 10. **Replace Firestore test-mode rules before Aug 19, 2026** (scoped rules given in chat July 20) — sync breaks silently when test mode expires. 11. Upload b6 index.html to GitHub (live is still the July 19 build). **BOOKED ✓ (July 2026): Sept 9 perfume workshop with Lina (Self Love / middi hiroo) — deposit paid, balance cash only, meeting point per Lina's instructions in the booking confirmation; Sept 9 MITUBACI ring workshop 15:00 — confirmed.** Both marked in Day 3 (app cards d3i3/d3i5 + CSV). |
| — | Sept 24-30 | Osaka — DRAFT SKELETON exists in **`osaka-planning-draft.md`** (July 20: day-by-day skeleton + verification checklist; nothing verified yet — start next session from that file). Note: source doc says skip Universal but Hanan (July 2026) wants it — ask GO/NO-GO. Umeda-mall note from Facebook post still to examine |
| — | Sept 30-Oct 2 | Hakone — NOT yet planned (source: "14. האקונה.docx") |
| — | Oct 2-12 | Final Tokyo stretch — NOT yet planned |

Other uploaded source docs not yet used: Okayama, Kurashiki, Yokohama, Fuji Five Lakes, Japanese Alps, Kamakura (already used), a second Tokyo/Shibuya version "from Nir."

## Source materials (copied into `source-materials/` in this folder)

All uploaded maps and city docs, copied here so they persist with the project instead of living only in a session-specific uploads folder:

| File | Covers |
|---|---|
| `2. טוקיו.kmz` | Tokyo — Hanan's own map |
| `f7728042-...-Tokyo by Ptitim.kmz` | Tokyo — Gal's map (ptitim.com), 736 placemarks across 10 folders |
| `3.2 טוקיו-Shibuya שיבויה - הגרסה של ניר.docx` | Tokyo/Shibuya — "Nir's version" |
| `4. קיוטו-אראשימה -נארה - Kibune Kurama.docx` | Kyoto/Arashiyama/Nara + Kibune/Kurama |
| `5. אוסאקה.docx` | Osaka |
| `7. אוקיאמה - Okayama.docx` | Okayama |
| `8. קוראשיקי Kurashiki.docx` | Kurashiki |
| `11. האלפים היפניים.docx` | Japanese Alps |
| `13. יוקוהמה Yokohama.docx` | Yokohama |
| `14. האקונה.docx` | Hakone |
| `15. חמשת האגמים ליד הר פוג'י.docx` | Fuji Five Lakes |
| `17. קמקורה Kamakura.docx` | Kamakura (already used for Sept 12) |

Note: no dedicated source file exists for Nagoya — confirmed by checking every uploaded file; Nagoya (Sept 18) was researched fresh instead.

## Named blogs / creators to use as sources

- **Gal (ptitim.com)** — Hebrew-language food blogger, personal Google My Maps KMZ (see Tokyo file above). Already cross-referenced into Sept 7-11.
- **Sunny in Japan** (YouTube @Sunny_in_Japan / Instagram @itssunnyinjapan) — long-term resident, Kyoto/Osaka-based. Use for Kyoto, Osaka, and their surrounding day trips.
- **Paolo from Tokyo** — established, long-running YouTube channel.
- **Crazy_japan_guide** — Instagram page.
- **Local Japan Travelers** — YouTube channel (@LocalJapanTravelers), added per Hanan (July 2026). Use for neighborhood-level spot ideas; every specific place taken from it must be verified against trusted Japanese sources (Tabelog etc.) before entering the itinerary. Already processed: Shimokitazawa video (watch?v=ZApPNFd_V9s, July 2026) → verified additions merged into Day 5. PARKED FOR LATER: their Kuramae video (watch?v=T9PD007NXaA) — process when planning the Oct 2-6 KAIKA (east Tokyo) stay.

See `source-materials/additional-sources-and-notes.md` for: a Tokyo cheap-eats chain list, unintegrated Takayama recommendations (Eden Marciano, Facebook) that still need to be checked against the Sept 15/16 days, an Osaka wagyu restaurant lead, and a cross-city coffee shop list (Osaka/Kyoto/Tokyo) from a personal Facebook post. That file also notes which of these sources meet our long-term-resident bar and which are generic/repost accounts to treat more cautiously.

## Leads parked for the final Tokyo stretch (Oct 2-12)

From Paolo from Tokyo's "Secret Tokyo Bars & Restaurants No One Knows About" (youtube.com/watch?v=2PaXAb8chuM, 2022) — mapped and verified July 2026. Hanan's decision (July 2026): **keep only Janai Coffee as relevant**; the other four are logged below solely so we don't re-suggest them:

- **Janai Coffee (ジャナイコーヒー)** — Ebisu, Yamanoi Bldg B1F, 2-3-13 Ebisu-Minami. Hidden bar behind a coffee stand; genuinely craft coffee-cocktails, ¥1,400-1,600/drink. 18:00-24:00, irregular holidays. Reservation via a puzzle on janaicoffee.tokyo. The most craft-credible pick in the video. Also relevant to Day 3 (Sept 9, Ebisu) as alternative/second stop to Bar TRENCH.
- **No Room For Squares (ノールームフォースクエアーズ)** — Shimokitazawa, Kitazawa 2-1-7, Housing Kitazawa Bldg 2, 4F. Jazz/hip-hop hidden bar behind a Coca-Cola vending machine. Split day/evening hours that vary by weekday (as of late 2024; re-verify). Also relevant to Day 5 (Sept 11, Shimokitazawa — Friday afternoon window).
- **Basashi Izakaya Ryunosuke (龍之介)** — Shinjuku-sanchome, 3-7-7 Shinjuku. Horse-meat (basashi) izakaya behind a fake fridge door. Food spot, not a cocktail bar.
- **MOSS Dining Bar** — Sangenjaya, Taishido 4-28-2. Meat-focused dining bar behind a vending-machine door; open (verified reviews from Apr 2026), 18:00-24:00. Food spot, not craft cocktails.
- **igu&peace (イグアンドピース)** — Shibuya, Dogenzaka 1-5-2, SEDE Bldg 4F — practically next to the Oct 6-12 hotel. Entrance behind a bookcase, "adult playground" theme (Mini Cooper, private rooms). Reads gimmick-first, not craft — low priority given traveler profile; kept only because it's 2 min from Hotel DIAMOND.

## Verified hidden/craft cocktail bar shortlist (scanned July 2026)

Discovered via Time Out Tokyo (approved discovery source), each cross-verified by reading its official Tabelog page. All open in 2026 unless noted. Grouped by trip leg:

**Near Sept 7-9 stay (Hamamatsucho) / Ebisu day:**
- **A10 (エーテン)** — Ebisu-Nishi 1-12-11, Bios Bldg B1F; entrance is a fake coin-locker wall across from Ebisu Park. Record bar + serious mixology (menu supervised by Shuzo Nagumo). Tabelog 3.58/310. Daily 19:00-2:30. Cover ¥1,320, ~¥4-5k spend. Fits Day 3 (Sept 9, Ebisu) alongside Bar TRENCH / Janai Coffee.

**Near Sept 10-12 stay (Kita-Shinjuku):**
- **The Open Book (ジオープンブック)** — Golden Gai 5th Ave, Kabukicho 1-1-6. 15-seat standing bar, best filtered lemon sour in Tokyo, run by novelist Komimasa Tanaka's grandson. Tabelog 3.30/93. Daily 20:00-23:55, ¥300 cover, ~¥2k spend, walk-in only. Fits Day 4 (Sept 10, light evening).
- **The Hisaka (ザ・ヒサカ)** — Takadanobaba, Takada 3-8-5. Japanese gin specialist, 200+ craft gins. Tabelog 3.32/41. Daily (Mon from 18:00, else 16:00-23:00), G&T happy hour 16:00-17:00, cashless only, ~¥4k. Caveat: no 2026-dated reviews seen — reconfirm before going.

**Oct 6-12 stay (Shibuya/Dogenzaka) — adds to existing SG Club / Bar Ishinohana / The Bellwood leads:**
- **SG Low (ゑすじ郎)** — Jinnan 1-9-4, NC Bldg 2F. Shingo Gokan's craft lemon-sour izakaya-bar; welcome martini as otoshi. Tabelog 3.43/230. Closed Wed, 17:00-23:00, ~¥5-6k, book online (fills up).
- **BW Cave (ビーダブリューケイブ)** — Udagawacho 41-29, 2F next to The Bellwood (Atsushi Suzuki). Martinis on tap + neo-Chinese bites. Tabelog 3.20/15 (opened Dec 2023). Closed Wed+Thu, 18:00-1:00, ~¥4-5k.

**Smoking audit (July 2026 — every bar's Tabelog smoking field read directly):** ALL of these are verified indoor non-smoking: Bar High Five, Bar TRENCH, SG Club, Bar Ishinohana, The Bellwood, The Open Book, The Hisaka, SG Low, BW Cave, Janai Coffee, Eagle. **A10 Ebisu FAILED (smoking allowed inside, e-cigs at all seats) — removed from consideration.**

**From Japanese-language sources (Tabelog Bar Hyakumeiten + 男の隠れ家/Hitosara/Retty), surviving the non-smoking filter:**
- **Eagle (イーグル)** — Shinjuku-sanchome, 新宿3-24-11 B1-B2F. Since 1966, underground Showa grand bar, seasonal fresh-fruit cocktails. Tabelog 3.73/1,009, Hyakumeiten 2022, non-smoking. Daily 17:00-23:30 (irregular Mon closures), cover ¥660+10%, ~¥5-6k. Fits Sept 10-12 Shinjuku nights.
- **Mixology Salon (ミクソロジーサロン)** — GINZA SIX 13F. Shuzo Nagumo's tea-cocktail ("teatail") bar — gyokuro martini, teatail flights. Tabelog 3.51/139, non-smoking. Daily 13:00-23:00, cover ¥880, ~¥4-8k, 8 seats — reserve. Fits Sept 7-9 Ginza evenings.
- **memento mori (メメントモリ)** — Toranomon Hills Business Tower 3F (short hop from Hamamatsucho hotel). Cacao-focused mixology, dedicated pastry chef. Tabelog 3.57/213, non-smoking. Daily 16:00-23:00 (weekends from 14:00), cover ¥880, ~¥6-8k, online booking. Fits Sept 6-9 stay.
- **Bar Triad** — Ebisu, 恵比寿西1-4-1 4F. Same Small Axe group as Bar TRENCH — herbal craft cocktails, larger reservable room; indoor non-smoking (balcony only). Tabelog 3.51/168. Daily 19:00-2:00, no cover, 10% service, ~¥2-4k. Backup if TRENCH is full on Day 3.
- **FUGLEN ASAKUSA** — 浅草2-6-15. Oslo cafe by day, Nordic craft-cocktail bar by night. Tabelog 3.58/611, non-smoking. Daily 8:00-21:00 (Fri-Sun to 23:00), walk-in, cheap. Best east-Tokyo fit for Oct 2-6 KAIKA stay. Casual hybrid, not a hushed counter bar.

**Rejected on smoking (do not re-suggest):** A10, LITTLE SMITH, BAR五, FOS, Bar El Laguito (also had a women-only-with-men door rule), Trois Chambres kissaten (Shimokitazawa — all-seats smoking). Rejected on fit: Donna Selvatica (spirits/chocolate, 3.09), Wall Aoyama (restaurant/wine bar), Bar Benfiddich (Thursdays-only hours), Bar Orchard Ginza (3.15), LIQUID FACTORY (3.25/34).

## Known open items / things to double check later

- Confirm whether other days' restaurant addresses (e.g. Steak House Kitchen Hida, sourced from Tabelog/Navitime) should be independently cross-checked against Google Maps.
- Nagoya day (Sept 18) currently has two substantial meals back to back (Yabaton miso katsu lunch + Houraiken hitsumabushi) — flagged as heavy, not yet resolved if user wants to lighten it.
