# Osaka Leg — Working Draft (Sept 24-30, 2026)

Status: SKELETON ONLY — nothing verified yet. Every pick below must pass the standing sourcing rules (Tabelog/Google Maps 3.5+/hundreds of reviews, smoking check, allergy check, Japanese script) before entering CSVs/app.

Base: Ruka Hotel Tennoji (Sept 24 ~15:30 arrival from Uji → Sept 30 morning checkout → Hakone).

## Inputs

- Source doc `5. אוסאקה.docx` (from the 2024 trip — partly post-trip verdicts):
  - Dotonbori: evening, 2-3 hrs. Canal boat option. IN PLAN per doc.
  - Namba quarter: Namba Parks, Hozenji alley, Den-Den Town.
  - Osaka Castle: morning, 3-4 hrs.
  - Abeno Harukas: 2-3 hrs, "nice but not a must" — RIGHT NEXT to Ruka Tennoji, easy sunset observatory slot.
  - Shitennoji Temple: 1-2 hrs, walkable from Tennoji.
  - Kuromon Market; Namba Yasaka Shrine (minutes, photogenic lion head).
  - Kaiyukan Aquarium: 2-3 hrs (harbor area).
  - teamLab Botanical Garden Nagai (evening; tickets teamlab.art/e/botanicalgarden) — fits traveler profile, they loved teamLab.
  - Hoshida Park (suspension bridge hike) — outside city, optional.
  - Post-trip verdict: street-food kushikatsu row = "greasy carbs, skip" → prefer quality sit-down over Dotonbori stall-hopping.
  - Doc says SKIP: Korean Town, Expo Park, Universal ("needs a full day") — BUT Hanan (July 2026) DOES want Universal Studios now; tickets are an open action item.
- `additional-sources-and-notes.md`:
  - Wagyu IDATEN (Namba, 1 min from station) — dinner lead, needs Tabelog verification (repost-account source).
  - SAKImoto Coffee (roastery + egg sando) — Osaka coffee anchor.
  - Hanakomachi (Minoh) — curry/honey/coffee near Minoh Falls trail → pairs with a Minoh half-day.
- Sunny in Japan (@itssunnyinjapan) — approved source for Osaka; mine her Osaka content next session.
- Cocktail bars: traveler profile requires craft-bar research for Osaka (Tabelog Hyakumeiten, smoking field check). None sourced yet.

## Draft day skeleton (to verify & fill)

| Date | Day | Draft |
|---|---|---|
| Sept 24 (Thu) eve | 18 | Arrival 15:30 → Tennoji orientation: Shinsekai evening stroll + dinner (doc: "if time" — it's next door) |
| Sept 25 (Fri) | 19 | Osaka Castle early (beat crowds) → Kuromon Market lunch → Namba Yasaka → Hozenji alley → Dotonbori at night (canal boat?) |
| Sept 26 (Sat) | 20 | Minoh half-day (falls trail + Hanakomachi) — out-of-city on the crowded Saturday → back for SAKImoto coffee + quality dinner (Wagyu IDATEN?) |
| Sept 27 (Sun) | 21 | Kaiyukan Aquarium + harbor OR quieter neighborhood day; evening teamLab Botanical Garden (book) |
| Sept 28 (Mon) | 22 | Universal Studios full day (IF tickets — weekday = lighter crowds; buy express pass?) |
| Sept 29 (Tue) | 23 | Shitennoji morning → Abeno Harukas observatory (sunset, next to hotel) → farewell dinner + craft cocktail bar |
| Sept 30 (Wed) | 24 | Checkout → transfer to Hakone (Sengokuhara Shinanoki Ichinoyu) — plan the route (Shinkansen Shin-Osaka→Odawara → Hakone) |

## Verification checklist (next session)

1. Mine Sunny in Japan's Osaka picks (food/coffee/neighborhoods) — she's the priority source here.
2. Verify Wagyu IDATEN on Tabelog (rating, smoking, hours) before adopting.
3. Research Osaka craft cocktail bars (Tabelog Bar Hyakumeiten; smoking field MUST be checked; no tourist-gimmick).
4. teamLab Botanical Garden: 2026 hours/tickets; evening slot logistics from Nagai back to Tennoji.
5. Universal Studios: ask Hanan GO/NO-GO (doc said skip, he now says go) → if GO, tickets + express pass + which day (Mon Sept 28 draft).
6. Minoh: trail status Sept 2026, Hanakomachi hours (it's small/home-style).
7. Every food pick vs allergies (peach/nectarine/kiwi — September parfait season!).
8. Kaiyukan vs alternatives — check crowd calendars for Sun Sept 27.
9. Transfer Sept 30 Osaka→Hakone: exact route/times, luggage (takkyubin again?).
